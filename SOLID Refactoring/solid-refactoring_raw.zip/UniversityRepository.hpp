#ifndef UNIVERSITYREPOSITORY_HPP_
#define UNIVERSITYREPOSITORY_HPP_

#include "University.hpp"

class UniversityRepository {
public:
    University getById(int universityId);
};


#endif /* UNIVERSITYREPOSITORY_HPP_ */
